import Sidebar from "./components/Sidebar";
import Home from "./components/Home";
import AboutMe from "./components/AboutMe";

function App() {
  return (
    <div className="bg-[#02050A] text-white flex">
      <Sidebar />
      <>
        <Home />
      <AboutMe/>
      </>
      
    </div>
  );
}

export default App;
